#pragma once

/** DO NOT INCLUDE DIRECTLY - should be included via board_definition.h */

#include <Arduino.h>
#include "src/pins/inputPin.h"
#include "src/pins/outputPin.h"

#define CORE_TEENSY35

/*
***********************************************************************************************************
* General
*/

/** @brief The timer overflow type
 * 
 * On some boards timers can overflow at less than the timer register width
 */
using COMPARE_TYPE = uint16_t;

namespace {
  /** @brief Tick resolution in µS */
  constexpr auto TICK_RESOLUTION = 2.13333333333333;

  /** @brief µS<->tick conversion precision in decimal places for fixed point math */
  constexpr uint32_t TICK_CONVERTER_PRECISION = 8UL;
}

/** @brief Convert µS to timer ticks */
static constexpr COMPARE_TYPE uS_TO_TIMER_COMPARE(uint32_t micros)
{
  constexpr uint32_t MULTIPLIER = (uint32_t)((1UL<<TICK_CONVERTER_PRECISION)/TICK_RESOLUTION);
  return (COMPARE_TYPE)((micros * MULTIPLIER) >> TICK_CONVERTER_PRECISION);
}

/** @brief Convert timer ticks to µS */
static constexpr uint32_t ticksToMicros(COMPARE_TYPE ticks)
{
  constexpr uint32_t MULTIPLIER = (uint32_t)((1UL<<TICK_CONVERTER_PRECISION)*TICK_RESOLUTION);
  return (ticks * MULTIPLIER) >> TICK_CONVERTER_PRECISION;
}

#define TS_SERIAL_BUFFER_SIZE 517 //Size of the serial buffer used by new comms protocol. For SD transfers this must be at least 512 + 1 (flag) + 4 (sector)
#define FPU_MAX_SIZE 32 //Size of the FPU buffer. 0 means no FPU.
#define SD_LOGGING //SD logging enabled by default for Teensy 3.5 as it has the slot built in
#define BOARD_MAX_DIGITAL_PINS 57
#define BOARD_MAX_IO_PINS 57
#define RTC_ENABLED
#define RTC_LIB_H "TimeLib.h"
#define SD_CONFIG  SdioConfig(FIFO_SDIO) //Set Teensy to use SDIO in FIFO mode. This is the fastest SD mode on Teensy as it offloads most of the writes
constexpr uint16_t BLOCKING_FACTOR = 251;
constexpr uint16_t TABLE_BLOCKING_FACTOR = 256;

#define PWM_FAN_AVAILABLE
static inline bool pinIsReserved(uint8_t pin) { 
  return (pin == 0U) 
      || (pin == 1U) 
      || (pin == 3U) 
      || (pin == 4U) 
  ;
}
#define INJ_CHANNELS 8
#define IGN_CHANNELS 8

/*
***********************************************************************************************************
* Schedules
*/
//shawnhymel.com/661/learning-the-teensy-lc-interrupt-service-routines/
#define FUEL1_COUNTER FTM0_CNT
#define FUEL2_COUNTER FTM0_CNT
#define FUEL3_COUNTER FTM0_CNT
#define FUEL4_COUNTER FTM0_CNT
#define FUEL5_COUNTER FTM3_CNT
#define FUEL6_COUNTER FTM3_CNT
#define FUEL7_COUNTER FTM3_CNT
#define FUEL8_COUNTER FTM3_CNT

#define IGN1_COUNTER  FTM0_CNT
#define IGN2_COUNTER  FTM0_CNT
#define IGN3_COUNTER  FTM0_CNT
#define IGN4_COUNTER  FTM0_CNT
#define IGN5_COUNTER  FTM3_CNT
#define IGN6_COUNTER  FTM3_CNT
#define IGN7_COUNTER  FTM3_CNT
#define IGN8_COUNTER  FTM3_CNT

#define FUEL1_COMPARE FTM0_C0V
#define FUEL2_COMPARE FTM0_C1V
#define FUEL3_COMPARE FTM0_C2V
#define FUEL4_COMPARE FTM0_C3V
#define FUEL5_COMPARE FTM3_C0V
#define FUEL6_COMPARE FTM3_C1V
#define FUEL7_COMPARE FTM3_C2V
#define FUEL8_COMPARE FTM3_C3V

#define IGN1_COMPARE  FTM0_C4V
#define IGN2_COMPARE  FTM0_C5V
#define IGN3_COMPARE  FTM0_C6V
#define IGN4_COMPARE  FTM0_C7V
#define IGN5_COMPARE  FTM3_C4V
#define IGN6_COMPARE  FTM3_C5V
#define IGN7_COMPARE  FTM3_C6V
#define IGN8_COMPARE  FTM3_C7V

static inline void FUEL1_TIMER_ENABLE(void)  {FTM0_C0SC |= FTM_CSC_CHIE;} //Write 1 to the CHIE (Channel Interrupt Enable) bit of channel 0 Status/Control
static inline void FUEL2_TIMER_ENABLE(void)  {FTM0_C1SC |= FTM_CSC_CHIE;}
static inline void FUEL3_TIMER_ENABLE(void)  {FTM0_C2SC |= FTM_CSC_CHIE;}
static inline void FUEL4_TIMER_ENABLE(void)  {FTM0_C3SC |= FTM_CSC_CHIE;}
static inline void FUEL5_TIMER_ENABLE(void)  {FTM3_C0SC |= FTM_CSC_CHIE;}
static inline void FUEL6_TIMER_ENABLE(void)  {FTM3_C1SC |= FTM_CSC_CHIE;}
static inline void FUEL7_TIMER_ENABLE(void)  {FTM3_C2SC |= FTM_CSC_CHIE;}
static inline void FUEL8_TIMER_ENABLE(void)  {FTM3_C3SC |= FTM_CSC_CHIE;}

static inline void FUEL1_TIMER_DISABLE(void)  {FTM0_C0SC &= ~FTM_CSC_CHIE;} //Write 0 to the CHIE (Channel Interrupt Enable) bit of channel 0 Status/Control
static inline void FUEL2_TIMER_DISABLE(void)  {FTM0_C1SC &= ~FTM_CSC_CHIE;}
static inline void FUEL3_TIMER_DISABLE(void)  {FTM0_C2SC &= ~FTM_CSC_CHIE;}
static inline void FUEL4_TIMER_DISABLE(void)  {FTM0_C3SC &= ~FTM_CSC_CHIE;}
static inline void FUEL5_TIMER_DISABLE(void)  {FTM3_C0SC &= ~FTM_CSC_CHIE;} //Write 0 to the CHIE (Channel Interrupt Enable) bit of channel 0 Status/Control
static inline void FUEL6_TIMER_DISABLE(void)  {FTM3_C1SC &= ~FTM_CSC_CHIE;}
static inline void FUEL7_TIMER_DISABLE(void)  {FTM3_C2SC &= ~FTM_CSC_CHIE;}
static inline void FUEL8_TIMER_DISABLE(void)  {FTM3_C3SC &= ~FTM_CSC_CHIE;}

static inline void IGN1_TIMER_ENABLE(void)  {FTM0_C4SC |= FTM_CSC_CHIE;}
static inline void IGN2_TIMER_ENABLE(void)  {FTM0_C5SC |= FTM_CSC_CHIE;}
static inline void IGN3_TIMER_ENABLE(void)  {FTM0_C6SC |= FTM_CSC_CHIE;}
static inline void IGN4_TIMER_ENABLE(void)  {FTM0_C7SC |= FTM_CSC_CHIE;}
static inline void IGN5_TIMER_ENABLE(void)  {FTM3_C4SC |= FTM_CSC_CHIE;}
static inline void IGN6_TIMER_ENABLE(void)  {FTM3_C5SC |= FTM_CSC_CHIE;}
static inline void IGN7_TIMER_ENABLE(void)  {FTM3_C6SC |= FTM_CSC_CHIE;}
static inline void IGN8_TIMER_ENABLE(void)  {FTM3_C7SC |= FTM_CSC_CHIE;}

static inline void IGN1_TIMER_DISABLE(void)  {FTM0_C4SC &= ~FTM_CSC_CHIE;}
static inline void IGN2_TIMER_DISABLE(void)  {FTM0_C5SC &= ~FTM_CSC_CHIE;}
static inline void IGN3_TIMER_DISABLE(void)  {FTM0_C6SC &= ~FTM_CSC_CHIE;}
static inline void IGN4_TIMER_DISABLE(void)  {FTM0_C7SC &= ~FTM_CSC_CHIE;}
static inline void IGN5_TIMER_DISABLE(void)  {FTM3_C4SC &= ~FTM_CSC_CHIE;}
static inline void IGN6_TIMER_DISABLE(void)  {FTM3_C5SC &= ~FTM_CSC_CHIE;}
static inline void IGN7_TIMER_DISABLE(void)  {FTM3_C6SC &= ~FTM_CSC_CHIE;}
static inline void IGN8_TIMER_DISABLE(void)  {FTM3_C7SC &= ~FTM_CSC_CHIE;}

/*
***********************************************************************************************************
* Auxiliaries
*/
#define ENABLE_BOOST_TIMER()  FTM1_C0SC |= FTM_CSC_CHIE
#define DISABLE_BOOST_TIMER() FTM1_C0SC &= ~FTM_CSC_CHIE

#define ENABLE_VVT_TIMER()    FTM1_C1SC |= FTM_CSC_CHIE
#define DISABLE_VVT_TIMER()   FTM1_C1SC &= ~FTM_CSC_CHIE

#define ENABLE_FAN_TIMER()    FTM2_C1SC |= FTM_CSC_CHIE
#define DISABLE_FAN_TIMER()   FTM2_C1SC &= ~FTM_CSC_CHIE

#define BOOST_TIMER_COMPARE   FTM1_C0V
#define BOOST_TIMER_COUNTER   FTM1_CNT
#define VVT_TIMER_COMPARE     FTM1_C1V
#define VVT_TIMER_COUNTER     FTM1_CNT
#define FAN_TIMER_COMPARE     FTM2_C1V
#define FAN_TIMER_COUNTER     FTM2_CNT

/*
***********************************************************************************************************
* Idle
*/
#define IDLE_COUNTER FTM2_CNT
#define IDLE_COMPARE FTM2_C0V

#define IDLE_TIMER_ENABLE() FTM2_C0SC |= FTM_CSC_CHIE
#define IDLE_TIMER_DISABLE() FTM2_C0SC &= ~FTM_CSC_CHIE

/*
***********************************************************************************************************
* CAN / Second serial
*/
#define SECONDARY_SERIAL_T HardwareSerial

#include <FlexCAN_T4.h>
#define NATIVE_CAN_AVAILABLE

using boardInputPin_t = inputPin_t;
using boardOutputPin_t = outputPin_t;

/** @brief Analog pin mapping */
constexpr uint8_t ANALOG_PINS[] = { _ANALOG_PINS_A0_A14, A15, A16, A17, A18, A19, A20, A21, A22, A23, A24, A25  };

/** @brief When the serial buffer is filled to greater than this threshold
 * value, the serial processing operations will be performed more urgently 
 * in order to avoid it overflowing. 
 */
constexpr uint8_t SERIAL_BUFFER_THRESHOLD = 0U;

#define MC33810_SUPPORT
