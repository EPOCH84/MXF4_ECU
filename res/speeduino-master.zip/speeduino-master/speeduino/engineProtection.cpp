#include "globals.h"
#include "engineProtection.h"
#include "maths.h"
#include "units.h"
#include "unit_testing.h"
#include "preprocessor.h"
#include "decoder_init.h"
#include "units.h"
#include "preprocessor.h"

TESTABLE_STATIC uint32_t oilProtEndTime;
TESTABLE_CONSTEXPR table2D_u8_u8_4 oilPressureProtectTable(&configPage10.oilPressureProtRPM, &configPage10.oilPressureProtMins);
TESTABLE_CONSTEXPR table2D_u8_u8_6 coolantProtectTable(&configPage9.coolantProtTemp, &configPage9.coolantProtRPM);

/* AFR protection state moved to file scope so unit tests can control/reset it */
TESTABLE_STATIC bool checkAFRLimitActive = false;
TESTABLE_STATIC unsigned long afrProtectedActivateTime = 0;

TESTABLE_INLINE_STATIC bool checkOilPressureLimit(const statuses &current, const config6 &page6, const config10 &page10, uint32_t currMillis)
{
  bool engineProtectOil = false; //Will be set true below if required

  if ( (page6.engineProtectType != PROTECT_CUT_OFF) 
    && (page10.oilPressureProtEnbl == true) 
    && (page10.oilPressureEnable == true))
  {
    uint8_t oilLimit = table2D_getValue(&oilPressureProtectTable, current.RPMdiv100);
    if(current.oilPressure < oilLimit)
    {
      //Check if this is the first time we've been below the limit
      if(oilProtEndTime == 0U) { oilProtEndTime = currMillis + TIME_TEN_MILLIS.toUser(page10.oilPressureProtTime); }
      /* Check if countdown has reached its target, if so then instruct to cut */
      engineProtectOil = (currMillis >= oilProtEndTime) || (current.engineProtect.oil);
    }
    else 
    { 
      oilProtEndTime = 0; //Reset the timer
    }
  }

  return engineProtectOil;
}

TESTABLE_INLINE_STATIC bool checkBoostLimit(const statuses &current, const config6 &page6)
{
  return (page6.engineProtectType != PROTECT_CUT_OFF)
      && (page6.boostCutEnabled) 
      && (current.MAP > (long)MAP.toUser(page6.boostLimit));
}

static inline bool canApplyAfrLimit(const config6 &page6, const config9 &page9)
{
  return (page6.engineProtectType != PROTECT_CUT_OFF) 
      && (page9.afrProtectEnabled != AFR_PROTECT_OFF) 
      && (page6.egoType == EGO_TYPE_WIDE);
}

static inline uint16_t getAfrO2Limit(const statuses &current, const config9 &page9)
{
  if (page9.afrProtectEnabled==AFR_PROTECT_FIXED) {
    return page9.afrProtectDeviation;
  } 
  if (page9.afrProtectEnabled==AFR_PROTECT_TABLE) {
    return current.afrTarget + (uint16_t)page9.afrProtectDeviation;
  }
  
  return UINT16_MAX;
}

static inline bool isAfrLimitCondtionActive(const statuses &current, const config9 &page9)
{
    return (current.MAP >= (long)MAP.toUser(page9.afrProtectMinMAP))
          && (current.RPMdiv100 >= page9.afrProtectMinRPM) 
          && (current.TPS >= page9.afrProtectMinTPS) 
          && (current.O2 >= getAfrO2Limit(current, page9)); 
}

TESTABLE_INLINE_STATIC bool checkAFRLimit(const statuses &current, const config6 &page6, const config9 &page9, uint32_t currMillis)
{
  /*
    To use this function, a wideband sensor is required.

    First of all, check whether engine protection is enabled,
    thereafter check whether AFR protection is enabled and at last
    if wideband sensor is used.
    
    After confirmation, the following conditions has to be met:
    - MAP above x kPa
    - RPM above x
    - TPS above x %
    - AFR threshold (AFR target + defined maximum deviation)
    - Time before cut

    See afrProtect variables in globals.h for more information.

    If all conditions above are true, a specified time delay is starting
    to count down in which leads to the engine protection function
    to be activated using selected protection cut method (e.g. ignition,
    fuel or both).

    For reactivation, the following condition has to be met:
    - TPS below x %
  */
  if ( canApplyAfrLimit(page6, page9) )
  {
    if (isAfrLimitCondtionActive(current, page9))
    {
      // All conditions fulfilled - start counter for 'protection delay'
      if(afrProtectedActivateTime==0U) 
      {
        afrProtectedActivateTime = currMillis + TIME_TEN_MILLIS.toUser(page9.afrProtectCutTime);
      }

      // Check if countdown has reached its target, if so then instruct to cut
      checkAFRLimitActive = currMillis >= afrProtectedActivateTime;
    } 
    else 
    {
      // NOTE: we deliberately do not reset checkAFRLimitActive here
      // Once AFR protection is in effect, user must reduce throttle
      // to below the reactivation limit to reset manually (below)

      // Do nothing
    }

    // Check if condition for reactivation is fulfilled
    if(current.TPS <= page9.afrProtectReactivationTPS)
    {
      checkAFRLimitActive = false;
      afrProtectedActivateTime = 0U;
    }
  }
  else
  {
    checkAFRLimitActive = false;
  }
  return checkAFRLimitActive;
}

TESTABLE_INLINE_STATIC bool checkRpmLimit(const statuses &current, const config4 &page4, const config6 &page6, const config9 &page9)
{
  return (page6.engineProtectType != PROTECT_CUT_OFF) 
      && (page9.hardRevMode == HARD_REV_FIXED)
      && ((current.RPMdiv100 >= page4.HardRevLim) 
        || ((softLimitTime > page4.SoftLimMax) && (current.RPMdiv100 >= page4.SoftRevLim)));
}

TESTABLE_INLINE_STATIC bool checkCoolantLimit(const statuses &current, const config6 &page6, const config9 &page9)
{
  return (page6.engineProtectType != PROTECT_CUT_OFF) 
      && (page9.hardRevMode == HARD_REV_COOLANT)
      && (current.RPMdiv100 > table2D_getValue(&coolantProtectTable, temperatureAddOffset(current.coolant)));
}

BEGIN_LTO_ALWAYS_INLINE(statuses::engine_protect_flags_t) checkEngineProtection(const statuses &current, const config4 &page4, const config6 &page6, const config9 &page9, const config10 &page10)
{
  statuses::engine_protect_flags_t flags = { false, false, false, false, false };

  if (page6.engineProtectType != PROTECT_CUT_OFF) 
  {
    // LCOV_EXCL_BR_START
    flags.boostCut = checkBoostLimit(current, page6);
    flags.oil = checkOilPressureLimit(current, page6, page10, millis());
    flags.afr = checkAFRLimit(current, page6, page9, millis());
    flags.coolant = checkCoolantLimit(current, page6, page9);
    flags.rpm = flags.coolant || checkRpmLimit(current, page4, page6, page9);
    // LCOV_EXCL_BR_STOP
  }

  return flags;
};
END_LTO_INLINE()

TESTABLE_INLINE_STATIC uint8_t getHardRevLimit(const statuses &current, const config4 &page4, const config9 &page9)
{
  if (page9.hardRevMode == HARD_REV_FIXED)
  {
    return page4.HardRevLim;
  }
  if (page9.hardRevMode == HARD_REV_COOLANT)
  {
    return table2D_getValue(&coolantProtectTable, temperatureAddOffset(current.coolant));
  }
  return UINT8_MAX;
}

TESTABLE_INLINE_STATIC uint8_t applyEngineProtectionRevLimit(uint8_t curLimit, const statuses &current, const config4 &page4)
{
  if ((current.engineProtect.boostCut) || (current.engineProtect.oil) || (current.engineProtect.afr))
  {
    return min(curLimit, page4.engineProtectMaxRPM);
  }

  return curLimit;
}

TESTABLE_INLINE_STATIC uint8_t applyHardLaunchRevLimit(uint8_t curLimit, const statuses &current, const config6 &page6)
{
  if (current.launchingHard)
  {
    return min(curLimit, page6.lnchHardLim);
  }

  return curLimit;
}

TESTABLE_INLINE_STATIC uint16_t applyFlatShiftRevLimit(uint16_t curLimit, const statuses &current)
{
  if ( current.flatShiftingHard ) 
  {
    return min(curLimit, (uint16_t)current.clutchEngagedRPM);
  }
  return curLimit;
}

TESTABLE_INLINE_STATIC uint16_t getMaxRpm(const statuses &current, const config4 &page4, const config6 &page6, const config9 &page9)
{
  // The maximum RPM allowed by all the potential limiters (Engine protection, 2-step, flat shift etc).
  // Divided by 100.
  return applyFlatShiftRevLimit(
          RPM_COARSE.toUser(applyHardLaunchRevLimit(
                              applyEngineProtectionRevLimit(
                                getHardRevLimit(current, page4, page9), 
                                current, page4),
                              current, page6)),
            current);
  
}

TESTABLE_STATIC uint32_t rollingCutLastRev = 0; /**< Tracks whether we're on the same or a different rev for the rolling cut */

// Test-hookable RNG for rolling cut (defaults to existing random1to100)
TESTABLE_STATIC uint8_t (*rollingCutRandFunc)(void) noexcept = random1to100;

constexpr statuses::scheduler_cut_t CUT_FULL_BOTH = { 
  .ignitionChannelsPending = 0x00, 
  .ignitionChannels = 0x00, 
  .fuelChannels = 0x00, 
  .status = SchedulerCutStatus::Full 
};
constexpr statuses::scheduler_cut_t CUT_FULL_FUEL = { 
  .ignitionChannelsPending = 0x00, 
  .ignitionChannels = 0xFF, 
  .fuelChannels = 0x00, 
  .status = SchedulerCutStatus::Full 
};
constexpr statuses::scheduler_cut_t CUT_FULL_IGN = { 
  .ignitionChannelsPending = 0x00, 
  .ignitionChannels = 0x00, 
  .fuelChannels = 0xFF, 
  .status = SchedulerCutStatus::Full 
};
constexpr statuses::scheduler_cut_t CUT_NONE = { 
  .ignitionChannelsPending = 0x00, 
  .ignitionChannels = 0xFF, 
  .fuelChannels = 0xFF, 
  .status = SchedulerCutStatus::None 
};

static inline statuses::scheduler_cut_t applyFullCut(const config6 &page6)
{
  //Full hard cut turns outputs off completely. 
  switch(page6.engineProtectType)
  {
    case PROTECT_CUT_IGN:
      return CUT_FULL_IGN;
      break;
    case PROTECT_CUT_FUEL:
      return CUT_FULL_FUEL;
      break;
    case PROTECT_CUT_BOTH:
    default:
      return CUT_FULL_BOTH;
      break;
  }
}

/**
 * @brief Immediately below max RPM, there is a range within which we can apply a rolling cut.
 * 
 * The rolling cut table defines a series of relative *negative* RPM offsets that
 * define the window and percent cut for each offset. I.e.
 *  RPM 0------------------------|++++++++++++++++++++|<- max RPM
 *                               | rolling cut window |
 */
TESTABLE_CONSTEXPR table2D_i8_u8_4 rollingCutTable(&configPage15.rollingProtRPMDelta, &configPage15.rollingProtCutPercent);

TESTABLE_INLINE_STATIC bool useRollingCut(const statuses &current, const config2 &page2, uint16_t maxAllowedRPM)
{
  //Limit for rolling is the max allowed RPM minus the lowest value in the delta table (Delta values are negative!)
  return (page2.hardCutType == HARD_CUT_ROLLING) 
      && (current.RPM < maxAllowedRPM)
      && (current.RPM > (maxAllowedRPM - RPM_MEDIUM.toUser(rollingCutTable.axis[0]*-1)));
}

static inline bool isNonSequential(const config2 &page2, const config4 &page4)
{
  return (page4.sparkMode != IGN_MODE_SEQUENTIAL) || (page2.injLayout != INJ_SEQUENTIAL);
}

static inline uint8_t calcBaseCutRevolutions(const config2 &page2)
{
  return (page2.strokes == FOUR_STROKE) ? 2U : 1U;
}

TESTABLE_INLINE_STATIC uint8_t calcRollingCutRevolutions(const config2 &page2, const config4 &page4)
{
  // 4 stroke and non-sequential will cut for 4 revolutions minimum. This is to ensure no half fuel ignition cycles take place
  if ( isNonSequential(page2, page4) ) 
  { 
    return calcBaseCutRevolutions(page2) * 2U; 
  } 
  return calcBaseCutRevolutions(page2);
}

TESTABLE_INLINE_STATIC uint8_t calcRollingCutPercentage(const statuses &current, uint16_t maxAllowedRPM)
{
  int16_t rpmDelta = current.RPM - maxAllowedRPM;
  //If the current RPM is over the max allowed RPM then cut is full (100%)
  if (rpmDelta >= 0) { 
    // 101 is used to make the comparison below simpler
    return 101U; 
  }
  // Avoid underflow
  if (rpmDelta<SIGNED_RPM_MEDIUM.toUser(INT8_MIN)) {
    return rollingCutTable.values[0];
  }
  
  return table2D_getValue(&rollingCutTable, SIGNED_RPM_MEDIUM.toRaw(rpmDelta) ); 
}

static inline statuses::scheduler_cut_t channelOff(statuses::scheduler_cut_t cutState, const config6 &page6, uint8_t channel)
{
  switch(page6.engineProtectType)
  {
    case PROTECT_CUT_IGN:
      BIT_CLEAR(cutState.ignitionChannels, channel); //Turn off this ignition channel
      break;
    case PROTECT_CUT_FUEL:
      BIT_CLEAR(cutState.fuelChannels, channel); //Turn off this fuel channel
      break;
    case PROTECT_CUT_BOTH:
    default:
      BIT_CLEAR(cutState.ignitionChannels, channel); //Turn off this ignition channel
      BIT_CLEAR(cutState.fuelChannels, channel); //Turn off this fuel channel
      break;
  }
  return cutState;
}

TESTABLE_INLINE_STATIC statuses::scheduler_cut_t channelOn(statuses::scheduler_cut_t cutState, bool supportPendingIgnitionCut, uint8_t channel)
{
  // Special case for non-sequential, 4-stroke where both fuel and ignition are cut.
  // The ignition pulses should wait 1 cycle after the fuel channels are turned back on before firing again
  if( supportPendingIgnitionCut &&
      //Fuel on this channel is currently off, meaning it is the first revolution after a cut
      (BIT_CHECK(cutState.fuelChannels, channel) == false))
  { 
    BIT_SET(cutState.ignitionChannelsPending, channel); //Set this ignition channel as pending
  }
  else 
  { 
    BIT_SET(cutState.ignitionChannels, channel); //Turn on this ignition channel
  }
          
  BIT_SET(cutState.fuelChannels, channel); //Turn on this fuel channel

  return cutState;
}

TESTABLE_STATIC bool supportPendingIgnitionCut(const config2 &page2, const config4 &page4, const config6 &page6)
{
  return (page2.strokes == FOUR_STROKE) 
      && isNonSequential(page2, page4)
      && (page6.engineProtectType == PROTECT_CUT_BOTH);
}

TESTABLE_STATIC statuses::scheduler_cut_t applyRollingCutPercentage(const statuses &current, const config6 &page6, uint8_t cutPercent, bool supportPendingIgnitionCut)
{
  statuses::scheduler_cut_t cutState = current.schedulerCutState;
  for(uint8_t channel=0; channel<max(current.maxIgnOutputs, current.maxInjOutputs); ++channel)
  {  
    if( rollingCutRandFunc() < cutPercent )
    {
      cutState = channelOff(cutState, page6, channel);
    }
    else
    {
      cutState = channelOn(cutState, supportPendingIgnitionCut, channel);
    }
  }
  cutState.status = SchedulerCutStatus::Rolling;
  return cutState;
}

//Check whether there are any ignition channels that are waiting for injection pulses to occur before being turned back on. This can only occur when at least 2 revolutions have taken place since the fuel was turned back on
//Note that ignitionChannelsPending can only be >0 on 4 stroke, non-sequential fuel when protect type is Both
TESTABLE_STATIC statuses::scheduler_cut_t applyPendingIgnitionCuts(statuses::scheduler_cut_t cutState, const statuses &current)
{
  if( (cutState.ignitionChannelsPending!=0U) && (current.startRevolutions >= (rollingCutLastRev + 2U)) )
  {
    cutState.ignitionChannels = cutState.fuelChannels;
    cutState.ignitionChannelsPending = 0U;
    cutState.status = SchedulerCutStatus::Rolling; 
  }
  return cutState;
}

TESTABLE_STATIC statuses::scheduler_cut_t applyRollingCut(const statuses &current, const config2 &page2, const config4 &page4, const config6 &page6, uint16_t maxAllowedRPM)
{
  if(rollingCutLastRev == 0U) { rollingCutLastRev = current.startRevolutions; } //First time check

  uint8_t revolutionsToCut = calcRollingCutRevolutions(page2, page4);
  if ( current.startRevolutions >= (rollingCutLastRev + revolutionsToCut)) //Check if the required number of revolutions have passed since the last cut
  { 
    rollingCutLastRev = current.startRevolutions;
    return applyPendingIgnitionCuts(
              applyRollingCutPercentage(current, 
                                        page6, 
                                        calcRollingCutPercentage(current, maxAllowedRPM), 
                                        supportPendingIgnitionCut(page2, page4, page6)),
              current);
  } 
  else
  {
    return applyPendingIgnitionCuts(current.schedulerCutState, current);
  }
}

statuses::scheduler_cut_t maskUnusedChannels(statuses::scheduler_cut_t cutState, const statuses &current)
{
  // Whatever the cut state is, ensure that any channels above the max outputs configured are masked off.  
  cutState.ignitionChannels = cutState.ignitionChannels & setBits(current.maxIgnOutputs); //Mask off unused ignition channels
  cutState.fuelChannels = cutState.fuelChannels & setBits(current.maxInjOutputs); //Mask off unused fuel channels
  return cutState;
}

BEGIN_LTO_ALWAYS_INLINE(statuses::scheduler_cut_t) calculateFuelIgnitionChannelCut(const statuses &current, const config2 &page2, const config4 &page4, const config6 &page6, const config9 &page9)
{
  statuses::scheduler_cut_t cutState = CUT_NONE;
  if ((current.decoder.getStatus().syncStatus==SyncStatus::None) || (current.startRevolutions < page4.StgCycles))
  {
    cutState = CUT_FULL_BOTH;
  }
  else if (page6.engineProtectType!=PROTECT_CUT_OFF)
  {
    // Determine the absolute max RPM
    uint16_t maxAllowedRPM = getMaxRpm(current, page4, page6, page9);

    // Full cut is always applied if RPM exceeds max allowed
    // regardless of page2.hardCutType
    if (current.RPM >= maxAllowedRPM)
    {
        cutState = applyFullCut(page6);
    }
    else if (useRollingCut(current, page2, maxAllowedRPM))
    { 
        cutState = applyRollingCut(current, page2, page4, page6, maxAllowedRPM);
    }
    else
    {
      // Nothing to do - default CUT_NONE will apply no cuts
    }
  }
  else
  {
    // Nothing to do - default CUT_NONE will apply no cuts
  }

  return maskUnusedChannels(cutState, current);
}
END_LTO_INLINE()
